(function(){
	"use strict";
	var app = angular.module('HomeModule', []);
	
	//start home page controller
	var HomePageCtrl = function($scope, $http, ItemsModel){
		  $scope.TestMessage = 'Hello Angular?';  //test to see if angular is working
		  $scope.model = ItemsModel.getItems();  // get image array from factory
		  $scope.ShowAddPic = "none";   //start add image modal as hidden
		  $scope.ShowDisplayPic = "none";  //start display large image modal as hidden
		  $scope.regex = '^(https?:\/\/)?([\\S\\.-]+)';  //simple regex for URL
		  $scope.PicTitle = ""; //set up variabiles for first use so error checking works first time
		  $scope.PicURL = "";
		  $scope.UserName = "";
		  $scope.PicComment = "";


		  //function to display modal to add a new image to model array
		  $scope.showAddPic = function () {
		      $scope.ShowAddPic = "block";
		     // $('#myModal').modal('show')  // can not use jquery, but is a little slicker using jquery
		  };

        //function to display image in large format and add comment
		  $scope.displayLarge = function (img) {
		      $scope.ShowDisplayPic = "block";
		      $scope.DisplayImageURL = img.imageURL;
		      $scope.DisplayTitle = img.title;
		      $scope.DisplayComments = img.comments;
		      $scope.img = img;
		  };

          


		  function getDateString() {
		      //"Feb 17, 2016 at 10:15am"  //approved format

		      var d = new Date();
		      var dTime = d.toLocaleTimeString();
		      var dstr = d.toDateString();
		      var darray = dstr.split(" ");
		      var tarray = dTime.split(":");
		      var ampm = dTime.split(" ");

		     //format date string in approved format
		      var str = darray[1] + " " + darray[2] + ", " + darray[3] + " at " + tarray[0] + ":" + tarray[1] + ampm[1].toLowerCase();
		      return str;

		  };

        //function to add a new image to the model arrary
		  $scope.SaveNewPic = function () {
		      var tsubmited = getDateString();
		     

		      if ($scope.PicTitle == "" || $scope.PicURL == "" || $scope.UserName == "" || $scope.PicComment == "") {
		          alert("Please enter data into all fields");
		          return;
		      }

              
              
		     var pic = {
		         title: $scope.PicTitle,
		         imageURL: $scope.PicURL,
		         comments: [{
		             user: $scope.UserName,
		             comment: $scope.PicComment,
		             timeSubmitted: tsubmited
		         }]
		     };

		      $http.post("http://azureservice.net/userx/saveNewPic", pic);
		      $scope.model.push(pic);
		      $scope.PicTitle = "";
		      $scope.PicURL = "";
		      $scope.UserName = "";
		      $scope.PicComment = "";
		      
		      $scope.CloseModal();
		  };

        //close modal for adding new pic
		  $scope.CloseModal = function () {
		      $scope.ShowAddPic = "none";
		      $scope.addForm.$setUntouched();
		  };

        //close modal for display large pic and add comment
		  $scope.CloseDisplay = function () {
		      $scope.ShowDisplayPic = "none";
		      $scope.myForm.$setUntouched();
		  };
		
        //Add a comment to the image
		  $scope.AddComment = function (img) {
		      //error chacking
		      if ($scope.UserName == "" || $scope.PicComment == "") {
		          alert("Please enter comment and user name.");
		          return;
		      }

		      var comment = {
		          user: $scope.UserName,
		          comment: $scope.PicComment,
                  timeSubmitted: getDateString()
		      };
		      $http.post("http://azureservice.net/userx/addComment", comment);  //dummy, real would have recordID in post data or api/method/id
		      img.comments.push(comment);

		      $scope.UserName = "";
		      $scope.PicComment = "";
		      $scope.myForm.$setUntouched();

		  };
		
	}; //end of HomePageCtrl
	
	
	






	
	
	 //register controller in the app module
	app.controller('HomePageCtrl', ["$scope", "$http", "ItemsModel",  HomePageCtrl]);
	
    //factory to generate image list
	app.factory('ItemsModel', function(){
		var items = [{
				title : "Moon",
				imageURL :"http://c1.staticflickr.com/9/8357/29972813016_6c67e6ac15_z.jpg",
				comments : [
				{
					user : "Guy 1",
					comment : "This is a good picture",
					timeSubmitted : "Feb 17, 2016 at 10:15am"
				}]
		},
        {
            title: "Space",
            imageURL: "http://c1.staticflickr.com/9/8414/29976342992_2df69ef7db.jpg",
            comments: [
            {
                user: "Tom",
                comment: "I like this picture",
                timeSubmitted: "Feb 19, 2016 at 10:05am"
            }]
        },
        {           
            title: "Rocket Ship",
            imageURL: "http://c5.staticflickr.com/9/8224/29832422012_45a337a318_n.jpg",
            comments: [
            {
                user: "Mike",
                comment: "this is my fav",
                timeSubmitted: "Mar 20, 2016 at 10:10am"
            }]
        }

		]
			
			function getItems(){
				return items;
			}
			
			return {
				getItems: getItems
			}
		
	});
	
	
	
	//template for small thumbnail image
	  app.directive('thumbnail', function () {
        return {
            templateUrl: 'content/templates/thumbnail.html',
			 restrict: 'E',
			replace: true
            
        }
    });
	
    //template for adding new picture to the list
	  app.directive('addPic', function () {
	      return {
	          templateUrl: 'content/templates/AddPic.html',
	          restrict: 'E',
	          replace: true

	      }
	  });
	 
    //template for displaying a picture in large format
	  app.directive('displayPic', function () {
	      return {
	          templateUrl: 'content/templates/ViewPic.html',
	          restrict: 'E',
	          replace: true

	      }
	  });
	
   
	
	
	
	
	
	
}());
